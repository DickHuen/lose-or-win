# btcperp - BTC-PERP bot for Polymarket Perps

**v2.3.0: forecast engine (analysis only)** (`FORECAST.md` in Chinese, `perpbot/forecast.py`): every 15-minute run
stores a forecast (price ranges, which way first, 500 / 1,000 / 2,000 USD move chances, early reversal warnings) and,
with a position, what a dynamic exit would do (shadow, never executed). Live trading is the v2.2.0 rules. Walk-forward:
ranges and move sizes calibrated, direction and warnings no better than the base rate; no backtest variant was
profitable after costs over 879 days (1h proxy). `forecast-check`, `intraday-compare`, `windows\Forecast_Check.bat`.

**v2.0.0 / v2.1.0: intraday rules every 15 minutes** (v2.1.0: looser values, range-edge fades, wick fix) (`intraday.enabled`; `INTRADAY.md` in Chinese, `perpbot/intraday.py`):
direction from closed 1h swing structure (long / short mirror-symmetric; continuation pullbacks and failed-retest
reversals; ranges skipped), structure stops at least as wide as max(1 ATR1h, 0.5%, cost / 0.20), two legs (TP1 1 R
then break-even + ATR trail, TP2 3 R), 1h-close invalidation, 12 h time stop, a cost gate from the real order book
and the account's fee rate, an incremental Binance candle cache with integrity checks and Retry-After handling, one
15-minute scheduled task, and a backtest / replay that call the same functions. The daily-score strategy below is
the v1.x path (intraday.enabled false).

Daily hybrid trend/structure strategy on BTC-PERP with exchange-side bracket stop-loss/take-profit,
fixed-risk sizing, gates, kill switches, full append-only logging, a local dashboard and Windows
desktop notifications. It runs on the owner's Windows PC from Windows Task Scheduler; see `START_HERE.md`
(Traditional Chinese). The code is cross-platform (the unit tests also run on Linux).

## Windows shortcuts (`windows\*.bat`)

| Shortcut | What it does |
|---|---|
| `1_Install.bat` | First install |
| `Upgrade.bat` | Upgrade from the newest zip in Downloads (asks for `UPGRADE`; `TEST-RESTORE` checks the automatic restore) |
| `Proxy_Key.bat` | Proxy key; the main wallet only signs (P: phone MetaMask on the same Wi-Fi; N: hardware wallet only, asks for `HARDWARE`; O: another computer) |
| `Edit_Secrets.bat` | Open .env in Notepad |
| `2_Smoketest.bat` | Smoketest: YES / W (+ withdrawal probe) / R |
| `Backtest.bat` | Backtest of the v1.x score strategy (asks for `CONFIRM` on the criteria the first time) |
| `Backtest_Intraday.bat` | v2.0.0: download 365 days of Binance 5m/15m/1h/4h candles and run the live 15-minute rules over 60 and 365 days, 4 cost scenarios |
| `Replay_Check.bat` | v2.0.0: recompute the last 3 days of live 15-minute decisions from the cached candles (expects `DIFFERENT: 0`) |
| `3_Schedule_Install.bat` | Go live (asks for `GO`; needs a passing full smoketest) |
| `Dashboard.bat` | Open the dashboard |
| `Status.bat` | Status |
| `Preview.bat` | What the strategy would decide right now, with the reasons (read-only, no keys, no orders) |
| `Pause_New_Entries.bat` | Stop new entries |
| `Unpause.bat` | Remove your manual pause only |
| `Kill_Close_Position.bat` | Close the position now (asks for `KILL`) |
| `Resume.bat` | Clear pauses (asks for `RESUME`, plus `RESET-PEAK` for a kill switch) |
| `Alerts.bat` | Print unread alerts |
| `Report_Daily.bat` | Daily report now |
| `Schedule_Check.bat` | Show the scheduled tasks and power settings |
| `Schedule_Remove.bat` | Remove the scheduled tasks (asks for `REMOVE`) |

Each one runs `venv\Scripts\python.exe run.py <command>` from the install folder, and refuses to run from any
other copy of the folder.

## Commands (`python run.py <command>`)

| Command | What it does |
|---|---|
| `decide` | v2.0.0 (intraday.enabled): every 15 minutes at HH:01/16/31/46 HKT from one repeating task: reconcile, update the candle cache, manage the open intraday position (TP1 -> break-even -> trail, invalidation, time / no-progress exits), then decide (entry only within 10 minutes of the candle close). v1.x: Every hour (rolling_1h, v1.9.0): HH:30 / HH:50 HKT, one entry per hour, entry window HH:30-HH+1:00 (rolling_4h: after each UTC 4h close, window HH:30-HH+1:30). Daily cadence: 08:30 / 08:50 HKT. Reconcile, then (only inside 08:30-09:30 HKT) compute the score from closed UTC daily candles, apply gates, log the decision and intent, and enter/flip/close. Idempotent: the second run completes or skips. New positions are blocked when the clock differs from the exchange by more than 30 s, or when the economic calendar's coverage has ended (closes still run). After the window with a position open and no decision yet: a late decision on the same data runs the close rules only. |
| `manage` | 12:30, 16:30, 20:30, 00:30, 04:30 HKT. Reconcile, complete a planned close, log position/market data. If no decision was made in today's window and a position is open, runs the late close-only decision. Never opens. |
| `intraday-backtest download\|run [--days N]` | v2.0.0: Binance history, then the live 15-minute functions under 4 cost scenarios x 2 sizings; `data/backtest_intraday/results_*/summary.md`. Never trades, no lock. |
| `intraday-replay [--days N]` | v2.0.0: recompute stored live 15-minute decisions from the cached candles and their logged inputs; exit code 1 if any differs. Read-only. |
| `report daily` / `weekly` / `monthly [--month YYYY-MM] [--only-first-sunday]` | Reports printed and saved in `data/reports/`; daily CSV export; weekly zipped CSV of all logs; monthly statistics file. |
| `alerts` | Print every unread alert once (`PING OWNER ...`) and mark it read (same list as the dashboard). |
| `snapshot` | Read-only exchange read for the dashboard (position, SL/TP, mark, equity). No orders, no state changes, no kill checks. Waits at most 5 s for the lock (skips if a run is busy); failures are logged, never alerted. |
| `dashboard [--port N] [--no-browser]` | Local web dashboard on `http://127.0.0.1:8765` (loopback only). No lock, no exchange access; reads the database. Its "refresh" button runs `snapshot`. |
| `schedule install\|remove\|list\|show [--dry-run] [--no-dashboard] [--upgrade]` | Windows Task Scheduler tasks under `\btcperp\`. Daily tasks are pinned to HKT (`+08:00`). `install` needs a passing full smoketest of this version with this proxy key; `--upgrade` re-registers tasks that already run from this folder. `show`/`list` also print the sleep and wake-timer settings. No lock. |
| `proxykey new --owner 0x.. [--days N<=30] [--offline] \| finish [--signature] \| status` | Create a proxy key here; the main wallet (fixed at `new`) only signs the one EIP-712 CreateProxy message (Polymarket, chain 137), which the signer builds itself: in a hardware wallet through a one-off page on 127.0.0.1:8766, or on another computer from `sign_fields.txt` with its own copy of `perpbot/offline_sign.py` or `offline_sign/offline_sign.html`. Registration and the .env write run under the bot lock. An unfinished request is deleted after 1 hour. `status` lists every registered proxy key. |
| `backtest download \| criteria \| confirm \| run` | See BACKTEST.md. `confirm` locks criteria, config, calendars, code, data end date, data hash and fee rate; `run` refuses any change and numbers the runs under a confirmation. Never trades; no lock. |
| `preview [--equity USD]` | Read-only: the decision the strategy would make now, as the readable analysis. Public Binance data only; no keys, no orders, nothing written. |
| `backup` | SQLite backup (+config) into `data/backups/` (last 14 + first of each month kept). |
| `status` | State, position, SL/TP, equity, drawdown, kill switches, last decision. |
| `pause` / `unpause` | Stop new entries (position and SL/TP kept) / remove only that manual pause. |
| `reasons` | Print the active pause reasons and what clears each one. |
| `kill` | Close the position with a reduce-only order, cancel its TP/SL by id, and pause. |
| `resume [--reset-peak]` | Clear pauses (only when the owner asks). A drawdown / losing-streak kill needs `--reset-peak` (exit code 6 without it): the peak is reset and the streak restarts. The equity floor needs a new config version stating `risk.equity_floor_reset_baseline_usd` (≤ current equity) and `risk.equity_floor_reset_for` = the trigger date; the permanent floor needs one with `risk.permanent_floor_reset_for` = the trigger date. Each is single use. |
| `selftest` | Run the unit tests (mocked exchange, no network). |
| `smoketest [--no-trade] [--probe-withdrawal]` | Live minimum-size test (START_HERE.md section 4). Records the exchange's status for an unfillable FOK. The withdrawal probe runs only with the flag. |
| `flowwatch [--minutes N]` | Record balances / deposit-withdrawal statuses while the owner makes a small deposit (only when flat). |

Every bot command takes an exclusive file lock (`data/btcperp.lock`), logs to `logs/btcperp_YYYY-MM-DD.log`
(secrets redacted), writes a start/end row to the run log, and on error exits non-zero and stores an
alert with the last log lines. Every alert is shown on the dashboard.

After the run, once the lock is released, Windows toasts are sent (at most 5 per run), so a slow
notification can never delay a trading action. Toasts use `notifications.windows_toast` (PowerShell WinRT,
text passed by environment variables). `decide` / `manage` also ping their optional heartbeat check
(`HEALTHCHECK_DECIDE_URL` / `HEALTHCHECK_MANAGE_URL`, fallback `HEALTHCHECK_PING_URL`): `<url>/start` when the run
starts, then `<url>` or `<url>/fail`. `/fail` is sent on an error, while a critical alert is unread, or while a
hard stop is active. Telegram is optional and off (`telegram.enabled`).
Exit codes: 0 ok, 1 error, 3 config / secrets / wrong folder, 4 lock busy, 5 selftest, 6 needs a typed
confirmation.

## Scheduling (Windows Task Scheduler)

`schedule install` writes one task XML per routine to `data/tasks/` and registers it with
`schtasks /Create /XML` (folder `\btcperp\`). Tasks run `venv\Scripts\pythonw.exe -m perpbot <command>`
(no console window) in the install folder, as the logged-on user (no stored Windows password: the user
must be logged on; a locked screen is fine), wake the computer, start as soon as possible after a missed
start (a late `decide` is logged as missed and never enters late), and queue instead of overlapping.
The first run of each task is its next future time, so registering never triggers a "missed" run.
If the PC is not on HKT, times are converted; the monthly report then runs weekly and
`--only-first-sunday` checks the HKT date. The dashboard task starts at logon.

## Dashboard

`http://127.0.0.1:8765`, bound to 127.0.0.1 only (exclusive port bind on Windows). The Host header must be
`127.0.0.1:<port>` or `localhost:<port>` (blocks DNS rebinding), and the two POST actions ("refresh from
exchange", "mark alerts read") need a per-server random token embedded in the page. Cards: state and pause
reasons, equity, drawdown / losing streak / equity floor against their limits, position with SL/TP and
liquidation price (latest `snapshot` or `manage`), latest decision with score components and gates, equity
curve with peak, statistics, trades, alerts, runs (last result per command, missed/late in 48 h, errors in
7 days), economic calendar and shadow variants.

## Every trading run starts with reconcile

1. Exchange position vs local trade record: a close that happened intraday (TP/SL/liquidation) is booked
   from the fills (net PnL after fees and funding) into the kill-switch statistics; an unknown position is
   adopted (an interrupted entry is recognised by its client order id).
2. If a position is open, an active SL must exist on the exchange; if not, a position SL is re-placed at the
   recorded price; if that fails (or the mark is already beyond it) the position is closed with a reduce-only
   order; if that fails too: "CLOSE FAILURE" alert.
3. When flat, leftover TP/SL/reduce-only orders are cancelled by id (never cancel-all, never auto-cancel).
4. `cumulative_funding` is recorded; fills and funding payments are synced.
5. (Only if Telegram is enabled in config: /pause, /kill, /status from the configured chat id.)
6. Equity log and kill switches. Equity = the exchange's `total_account_value` for both peak and current
   (wallet + uPnL is a cross-check; disagreement blocks new entries). Drawdown 25% from peak (v1.5.8; confirmed
   deposits/withdrawals adjust the peak) -> close and pause; losing streak with cumulative loss of 20% of equity (v1.5.8)
   (a trade within +/-0.1% of equity at entry is a tie: it neither ends nor extends the streak, review D11)
   -> pause, keep SL/TP; equity below 75% of net funded capital -> close and hard stop (`resume` cannot clear
   it; only a new config version that states the new baseline and the trigger date); equity below 50% of all
   capital ever funded (never re-based; review F1) -> close and stop for good (a config may never lower the %);
   after 30 live trades, a rolling 30-trade expectancy below the backtest's review line (S9) -> pause new entries;
   a failed kill close is retried every run; pending deposits/withdrawals skip
   the drawdown/floor checks and block entries; 25-trade size-weighted expectancy < 0 -> warning.
   Proxy key expiry alert 5 days ahead. (75% and 50% confirmed by the owner 2026-09-30; v1.5.8: 5% risk, 150% notional cap, 25% / 20% kills.)
7. A missing position on one read is not trusted: closes are booked and leftover orders cancelled only with
   evidence (exit fills, fired trigger, or two reads apart).

## Strategy (all numbers in `config/config.yaml`)

- Cadence (`strategy.cadence`): `rolling_1h` (v1.9.0, owner) decides every hour on daily candles that END at the
  decision time (built from Binance 1h candles; the h4 gate uses the last closed 4h candle), one entry per hour,
  3-day rule = 72 periods; `rolling_4h` (v1.5.0 - v1.8.1) the same every 4 hours from 4h candles (18 periods);
  `daily` once a day on candles closed at 00:00 UTC. Everything below applies to all three.

- Score = Trend (50 x clip((C - EMA50) / (2 x ATR14), -1, 1)) + Structure (+/-25 breakout of previous
  day high/low, + 25 x CLV; CLV = 0 if H = L), from closed UTC 00:00 daily candles (Binance BTCUSDT).
  Score exactly 0 (after rounding to 4 decimals) = no signal.
- Size tier by |score|: < 30 -> 25%, 30-50 -> 50%, > 50 -> 100% of the risk budget.
- Gates (caps: minimum, never multiplied): EMA200 regime against signal -> cap 50%; last closed 4h candle
  (20:00-00:00 UTC) EMA20/EMA50 disagrees -> cap 50%; Binance funding 365-day point-in-time percentile
  > p95 no new long, < p5 no new short; event window (08:30 HKT before an FOMC/CPI/NFP release until
  release + 4 h, DST-aware) -> no new positions, no flips; region blocked -> no entry.
- Holding: opposite |score| >= 30 -> flip (reduce-only IOC close, confirm flat with no leftover orders,
  then FOK bracket entry); weaker opposite -> hold; 3 consecutive UTC days of opposite signal -> close and
  re-enter per today's signal and gates; crowded side of extreme funding -> close and re-enter per gates.
- One entry per UTC day. Entry window 08:30-09:30 HKT; after that "missed", no late entry (the day's close
  rules are still evaluated late on the same data, close part only).
- Entry: FOK limit at best bid/ask +/- 10 bps with bracket SL 2 x / TP 3 x the 1h ATR(14) closed at the period start, at least 0.5% / 0.8% of the price (v1.10.0, `exits.atr_source` 1h; v1.8.1 used 1.0 / 1.5 x the daily ATR, before that 1.5 / 3) (mark-triggered,
  full size); `exits.entry_attempts` = 1 until the smoketest has recorded the real "FOK not filled" status; then no
  entry that day.
- **Bold mode (v1.7.0; off since v1.8.0, `bold.enabled` false):** every entry is one all-in bet: position = equity x 19 at
  20x isolated; TP where equity doubles after both taker fees (~+5.4%), SL where the loss incl. fees is 70% of
  equity (~-3.6%); refused if the liquidation estimate (~4% at 20x on max 50x) is not beyond the SL by 0.3% of the
  price, and closed after the fill if the exchange's liquidation price is not. While a bet is open, flips, the
  3-day rule and the funding / flat rules are ignored: it ends only at its TP or SL. Kill switches 95%, floors 5%,
  live review line off: the bot keeps betting until the owner pauses it. The rules below apply when bold mode is off.
- **Position by score (v1.8.0 / v1.9.0, owner):** no new position below |score| 20; position = equity x 20
  (`risk.notional_multiple_full_tier`) x the `strategy.size_tiers` fraction: 20-40 -> 0.15 (x3), 40-50 -> 0.30 (x6),
  50-75 -> 0.50 (x10), 75 and above -> 1.00 (x20), capped at 0.50 (x10) by a gate against the trade. Each trade uses
  the lowest isolated leverage whose margin fits in 92% of equity (x3 4x, x6 7x, x10 11x, x20 22x; at most 25x);
  if the liquidation estimate at that leverage is not 1.3 x the stop away, the position is cut until it is
  (volatility cap); after the fill the exchange's liquidation price must be 1.15 x the stop away. Never added to.
- Risk (v1.5.8, owner; used when `notional_multiple_full_tier` is null): 5% of equity at SL for the 100% tier (no half-size ramp); a size below the exchange
  minimum is raised to it if that risk stays within the 100%-tier budget; leverage 10x isolated (v1.5.9)
  (checked/set before every entry; failure = no trade), notional <= 150% of equity,
  liquidation price must be >= 2 x SL distance away (pre-trade estimate and post-fill check on the
  exchange's value; a missing liquidation price fails the check).
- A rejected or unknown FOK is never retried in the same run (the SDK reports a whole bracket as rejected
  even if the entry row filled); the retry needs proof the first order did not fill.

## Data (`data/btcperp.sqlite3`, append-only; UPDATE/DELETE blocked by triggers)

Every row has UTC and HKT timestamps, config version and code version. Tables: `runs`, `decisions`
(all raw inputs, score breakdown, gates, plan and reasons), `intents`/`intent_events` (the daily plan,
written before any order, and its steps), `orders` (requests, responses, status checks, fills, slippage,
latency), `fills`, `funding_payments`, `trades` (open/update/close with exit reason, MAE/MFE, holding
hours, fees, funding, net PnL, R), `manage_log`, `equity_log`, `state_log`, `position_snapshots`,
`market_snapshots` (mark, index, funding, spread, depth), `pm_klines_1h`/`pm_klines_1d`/`pm_funding`
(our own Polymarket dataset, backfilled every run), `bn_klines_1d`/`bn_klines_4h`/`bn_funding`,
`shadow_log`, `alerts`, `alert_deliveries`, `dash_snapshots`, `backtest_log`, `telegram_updates`, `flows`.

Shadow tracking (simulation only): each day a gate blocked or reduced a trade gets a hypothetical trade
(bracket outcome on Polymarket 1h candles); parallel variants `live_rules`, `v2_breakeven` (one-time SL
to breakeven at +1 ATR), `flat_allowed` (|score| < 30 = flat) and `ungated` are replayed from the logged
decisions.

## Layout

```
run.py            launcher (uses ./venv)          install.py     installer / upgrader
config/           config.yaml, calendar.yaml       perpbot/       code
tests/            unit tests (selftest)            API_NOTES.md   exchange API notes (untested items)
windows/          .bat shortcuts                   START_HERE.md  setup guide (Traditional Chinese)
BACKTEST.md       backtest design + criteria       REVIEW_v*.md   committee reviews and what was done
data/  logs/      created at install, never in the zip, never touched by upgrades
.env              secrets (created from .env.example), never in the zip
```

Exchange access uses Polymarket's official Python SDK (`polymarket-client`, pinned) with the proxy signer
only; the main wallet key is never used. See `API_NOTES.md`.
